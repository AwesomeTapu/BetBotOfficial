import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import TeamSelector from './components/TeamSelector';
import StatComparison from './components/StatComparison';
import PredictionResult from './components/PredictionResult';
import HeadToHeadHistory from './components/HeadToHeadHistory';
import { getTeamStats, getHeadToHeadStats } from './data/mockStatsService';
import { PredictionEngine } from './services/predictionEngine';
import { NBATeam, TeamStats, HeadToHeadStats, Prediction } from './types';

function App() {
  const [team1, setTeam1] = useState<NBATeam | null>(null);
  const [team2, setTeam2] = useState<NBATeam | null>(null);
  const [team1Stats, setTeam1Stats] = useState<TeamStats | null>(null);
  const [team2Stats, setTeam2Stats] = useState<TeamStats | null>(null);
  const [headToHeadStats, setHeadToHeadStats] = useState<HeadToHeadStats | null>(null);
  const [prediction, setPrediction] = useState<Prediction | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Effect to fetch stats when teams are selected
  useEffect(() => {
    if (team1 && team2) {
      setIsLoading(true);
      
      // Simulate API delay
      const timer = setTimeout(() => {
        const stats1 = getTeamStats(team1);
        const stats2 = getTeamStats(team2);
        const h2h = getHeadToHeadStats(team1, team2);
        
        setTeam1Stats(stats1);
        setTeam2Stats(stats2);
        setHeadToHeadStats(h2h);
        
        // Generate prediction
        const newPrediction = PredictionEngine.predict(team1, team2, stats1, stats2, h2h);
        setPrediction(newPrediction);
        setIsLoading(false);
      }, 1500);
      
      return () => clearTimeout(timer);
    } else {
      setTeam1Stats(null);
      setTeam2Stats(null);
      setHeadToHeadStats(null);
      setPrediction(null);
    }
  }, [team1, team2]);

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <main className="container mx-auto px-4 py-6 max-w-6xl">
        <section className="mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4">Select Teams to Compare</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <TeamSelector
                onTeamSelect={setTeam1}
                selectedTeam={team1}
                label="Team 1"
                otherSelectedTeam={team2}
              />
              <TeamSelector
                onTeamSelect={setTeam2}
                selectedTeam={team2}
                label="Team 2"
                otherSelectedTeam={team1}
                disabled={!team1}
              />
            </div>
            
            <div className="mt-4 text-center text-gray-500 text-sm">
              {!team1 ? (
                <p>Start by selecting the first team</p>
              ) : !team2 ? (
                <p>Now select the second team</p>
              ) : null}
            </div>
          </div>
        </section>
        
        {team1 && team2 && (
          <section className="mb-8 animate-fadeIn">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Prediction Result */}
              <div>
                <PredictionResult 
                  prediction={prediction}
                  team1={team1}
                  team2={team2}
                  isLoading={isLoading}
                />
              </div>
              
              {/* Head to Head History */}
              <div>
                {team1Stats && team2Stats && headToHeadStats && (
                  <HeadToHeadHistory
                    team1={team1}
                    team2={team2}
                    headToHeadStats={headToHeadStats}
                  />
                )}
              </div>
            </div>
          </section>
        )}
        
        {team1Stats && team2Stats && (
          <section className="animate-fadeIn">
            <StatComparison
              team1={team1!}
              team2={team2!}
              team1Stats={team1Stats}
              team2Stats={team2Stats}
            />
          </section>
        )}
      </main>
      
      <footer className="bg-gray-800 text-white p-4 mt-10">
        <div className="container mx-auto text-center">
          <p className="text-sm">NBA Betting Analyzer | Results are for entertainment purposes only</p>
          <p className="text-xs text-gray-400 mt-1">Not affiliated with the NBA or any NBA team</p>
        </div>
      </footer>
    </div>
  );
}

export default App;