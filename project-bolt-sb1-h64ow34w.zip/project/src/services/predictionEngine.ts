import { NBATeam, TeamStats, HeadToHeadStats, Prediction, Player } from '../types';

export class PredictionEngine {
  static predict(
    team1: NBATeam,
    team2: NBATeam,
    team1Stats: TeamStats,
    team2Stats: TeamStats,
    headToHead: HeadToHeadStats
  ): Prediction {
    // Calculate base statistical advantages
    const statDifferences = this.calculateStatDifferences(team1Stats, team2Stats);
    
    // Calculate head-to-head advantage
    const h2hAdvantage = this.calculateHeadToHeadAdvantage(headToHead);
    
    // Calculate injury impact
    const injuryImpact = this.calculateInjuryImpact(team1Stats.injuredPlayers || [], team2Stats.injuredPlayers || []);
    
    // Calculate key matchup advantages
    const keyMatchups = this.analyzeKeyMatchups(team1, team2);
    
    // Calculate recent form advantage
    const recentFormAdvantage = this.calculateRecentFormAdvantage(
      team1Stats.lastTenGamesStats,
      team2Stats.lastTenGamesStats
    );
    
    // Calculate overall win probability
    const team1Score = this.calculateTeamScore(
      statDifferences,
      h2hAdvantage,
      injuryImpact,
      recentFormAdvantage
    );
    
    const winProbability = this.normalizeWinProbability(team1Score);
    
    // Determine winner
    const winner = winProbability >= 50 ? team1 : team2;
    const actualWinProbability = winProbability >= 50 ? winProbability : 100 - winProbability;
    
    // Determine confidence level
    const confidenceLevel = this.determineConfidenceLevel(
      actualWinProbability,
      injuryImpact.severity
    );
    
    // Generate predicted score
    const predictedScore = this.generatePredictedScore(
      team1Stats,
      team2Stats,
      winner.id === team1.id ? actualWinProbability : 100 - actualWinProbability
    );
    
    // Generate key reasons
    const keyReasons = this.generateKeyReasons(
      team1,
      team2,
      statDifferences,
      h2hAdvantage,
      injuryImpact,
      winner.id === team1.id
    );
    
    return {
      winner,
      winProbability: actualWinProbability,
      confidenceLevel,
      keyReasons,
      keyMatchups,
      injuryImpact,
      predictedScore
    };
  }

  private static calculateInjuryImpact(
    team1Injuries: Player[],
    team2Injuries: Player[]
  ): Prediction['injuryImpact'] {
    // Calculate impact based on injured players' stats and importance
    const calculateTeamImpact = (injuries: Player[]): number => {
      return injuries.reduce((impact, player) => {
        const statImpact = (
          player.stats.pointsPerGame +
          player.stats.reboundsPerGame +
          player.stats.assistsPerGame
        ) / 30; // Normalize to 0-1 scale
        return impact + statImpact;
      }, 0);
    };

    const team1Impact = calculateTeamImpact(team1Injuries);
    const team2Impact = calculateTeamImpact(team2Injuries);
    
    const details: string[] = [];
    if (team1Injuries.length > 0) {
      details.push(`Key players out: ${team1Injuries.map(p => p.name).join(', ')}`);
    }
    if (team2Injuries.length > 0) {
      details.push(`Key players out: ${team2Injuries.map(p => p.name).join(', ')}`);
    }

    const totalImpact = Math.max(team1Impact, team2Impact);
    const severity: 'Low' | 'Medium' | 'High' = 
      totalImpact > 0.5 ? 'High' :
      totalImpact > 0.2 ? 'Medium' : 'Low';

    return {
      severity,
      details
    };
  }

  private static analyzeKeyMatchups(team1: NBATeam, team2: NBATeam) {
    // Analyze player matchups at each position
    const positions = ['PG', 'SG', 'SF', 'PF', 'C'];
    
    return positions.map(pos => {
      const team1Player = team1.roster.find(p => p.position === pos && p.status === 'Active');
      const team2Player = team2.roster.find(p => p.position === pos && p.status === 'Active');
      
      if (!team1Player || !team2Player) return null;

      const advantage = this.comparePlayerStats(team1Player, team2Player);
      
      return {
        position: pos,
        team1Player,
        team2Player,
        advantage: advantage > 0 ? team1Player.name : team2Player.name,
        reason: this.generateMatchupReason(team1Player, team2Player)
      };
    }).filter(Boolean);
  }

  private static comparePlayerStats(player1: Player, player2: Player): number {
    const stats1 = player1.stats;
    const stats2 = player2.stats;
    
    // Calculate overall impact score
    const getImpactScore = (stats: typeof stats1) => {
      return (
        stats.pointsPerGame * 1.0 +
        stats.reboundsPerGame * 0.7 +
        stats.assistsPerGame * 0.7 +
        stats.stealsPerGame * 0.5 +
        stats.blocksPerGame * 0.5 +
        (stats.fieldGoalPercentage / 100) * 0.8 +
        (stats.threePointPercentage / 100) * 0.6 +
        stats.plusMinus * 0.3
      );
    };

    return getImpactScore(stats1) - getImpactScore(stats2);
  }

  private static generateMatchupReason(player1: Player, player2: Player): string {
    const stats1 = player1.stats;
    const stats2 = player2.stats;
    
    if (stats1.pointsPerGame - stats2.pointsPerGame > 5) {
      return `${player1.name} averaging ${stats1.pointsPerGame.toFixed(1)} PPG vs ${stats2.pointsPerGame.toFixed(1)} PPG`;
    }
    
    if (stats1.assistsPerGame - stats2.assistsPerGame > 2) {
      return `${player1.name} superior playmaking with ${stats1.assistsPerGame.toFixed(1)} APG`;
    }
    
    return `Even matchup between ${player1.name} and ${player2.name}`;
  }

  private static calculateRecentFormAdvantage(
    team1Recent: TeamStats['lastTenGamesStats'],
    team2Recent: TeamStats['lastTenGamesStats']
  ): number {
    const team1Form = (
      team1Recent.ppg -
      team1Recent.oppPpg +
      team1Recent.avgMargin
    ) / 3;
    
    const team2Form = (
      team2Recent.ppg -
      team2Recent.oppPpg +
      team2Recent.avgMargin
    ) / 3;
    
    return (team1Form - team2Form) / 10; // Normalize to roughly -1 to 1 scale
  }

  private static generatePredictedScore(
    team1Stats: TeamStats,
    team2Stats: TeamStats,
    winProbability: number
  ) {
    const baseScore1 = team1Stats.ppg;
    const baseScore2 = team2Stats.ppg;
    
    // Adjust scores based on win probability
    const margin = Math.round((winProbability - 50) / 5); // Each 5% above 50% = 1 point
    
    return {
      team1: Math.round(baseScore1 + margin / 2),
      team2: Math.round(baseScore2 - margin / 2)
    };
  }

  // Calculate differences between team stats
  private static calculateStatDifferences(team1Stats: TeamStats, team2Stats: TeamStats) {
    return {
      ppg: team1Stats.ppg - team2Stats.ppg,
      fgPercentage: team1Stats.fgPercentage - team2Stats.fgPercentage,
      tpPercentage: team1Stats.tpPercentage - team2Stats.tpPercentage,
      ftPercentage: team1Stats.ftPercentage - team2Stats.ftPercentage,
      reboundsPerGame: team1Stats.reboundsPerGame - team2Stats.reboundsPerGame,
      turnoversPerGame: -(team1Stats.turnoversPerGame - team2Stats.turnoversPerGame),
      assistsPerGame: team1Stats.assistsPerGame - team2Stats.assistsPerGame,
      defensiveRating: -(team1Stats.defensiveRating - team2Stats.defensiveRating),
      offensiveRating: team1Stats.offensiveRating - team2Stats.offensiveRating,
      pace: team1Stats.pace - team2Stats.pace,
      homeWinPercentage: team1Stats.homeWinPercentage - team2Stats.homeWinPercentage,
      awayWinPercentage: team1Stats.awayWinPercentage - team2Stats.awayWinPercentage
    };
  }
  
  private static calculateHeadToHeadAdvantage(headToHead: HeadToHeadStats): number {
    const totalGames = headToHead.team1Wins + headToHead.team2Wins;
    if (totalGames === 0) return 0;
    return (headToHead.team1Wins - headToHead.team2Wins) / totalGames;
  }
  
  private static calculateTeamScore(
    statDifferences: any,
    h2hAdvantage: number,
    injuryImpact: Prediction['injuryImpact'],
    recentFormAdvantage: number
  ): number {
    const weights = {
      ppg: 2,
      fgPercentage: 2,
      tpPercentage: 1.5,
      ftPercentage: 1,
      reboundsPerGame: 1.5,
      turnoversPerGame: 1,
      assistsPerGame: 1,
      defensiveRating: 2,
      offensiveRating: 2,
      pace: 0.5,
      homeWinPercentage: 1,
      awayWinPercentage: 1
    };
    
    let score = 0;
    let totalWeight = 0;
    
    for (const [stat, difference] of Object.entries(statDifferences)) {
      const weight = weights[stat as keyof typeof weights];
      score += (difference as number) * weight;
      totalWeight += weight;
    }
    
    const normalizedScore = score / totalWeight;
    
    // Adjust score based on injuries and recent form
    const injuryAdjustment = injuryImpact.severity === 'High' ? -0.5 :
                            injuryImpact.severity === 'Medium' ? -0.3 : 0;
    
    return (normalizedScore * 0.6) + (h2hAdvantage * 0.2) + (recentFormAdvantage * 0.2) + injuryAdjustment;
  }
  
  private static normalizeWinProbability(score: number): number {
    const probability = 1 / (1 + Math.exp(-score * 3));
    return probability * 100;
  }
  
  private static determineConfidenceLevel(
    winProbability: number,
    injurySeverity: 'Low' | 'Medium' | 'High'
  ): 'Low' | 'Medium' | 'High' {
    if (injurySeverity === 'High') return 'Low';
    if (injurySeverity === 'Medium' && winProbability < 60) return 'Low';
    if (winProbability >= 65) return 'High';
    if (winProbability >= 55) return 'Medium';
    return 'Low';
  }
  
  private static generateKeyReasons(
    team1: NBATeam,
    team2: NBATeam,
    statDifferences: any,
    h2hAdvantage: number,
    injuryImpact: Prediction['injuryImpact'],
    team1IsWinner: boolean
  ): string[] {
    const reasons: string[] = [];
    const winningTeam = team1IsWinner ? team1 : team2;
    const losingTeam = team1IsWinner ? team2 : team1;
    
    const adjustedDiffs = team1IsWinner 
      ? statDifferences 
      : Object.fromEntries(
          Object.entries(statDifferences).map(([key, value]) => [key, -(value as number)])
        );
    
    const statEntries = Object.entries(adjustedDiffs)
      .filter(([stat]) => stat !== 'pace')
      .sort((a, b) => Math.abs(b[1] as number) - Math.abs(a[1] as number));
    
    const topStats = statEntries.slice(0, 3);
    
    for (const [stat, value] of topStats) {
      if (Math.abs(value as number) < 0.5) continue;
      
      const formattedValue = Math.abs(parseFloat((value as number).toFixed(1)));
      
      switch (stat) {
        case 'ppg':
          reasons.push(`${winningTeam.name} scores ${formattedValue} more points per game`);
          break;
        case 'fgPercentage':
          reasons.push(`${formattedValue}% better field goal percentage`);
          break;
        case 'tpPercentage':
          reasons.push(`${formattedValue}% better three-point shooting`);
          break;
        case 'reboundsPerGame':
          reasons.push(`${formattedValue} rebounding advantage per game`);
          break;
        case 'assistsPerGame':
          reasons.push(`${formattedValue} more assists per game`);
          break;
        case 'turnoversPerGame':
          reasons.push(`${formattedValue} fewer turnovers per game`);
          break;
        case 'defensiveRating':
          reasons.push(`Stronger defensive rating (${formattedValue} points better)`);
          break;
        case 'offensiveRating':
          reasons.push(`Superior offensive efficiency (${formattedValue} points better)`);
          break;
      }
    }
    
    if (Math.abs(h2hAdvantage) >= 0.33) {
      if ((h2hAdvantage > 0 && team1IsWinner) || (h2hAdvantage < 0 && !team1IsWinner)) {
        reasons.push(`${winningTeam.name} has dominated recent head-to-head matchups`);
      }
    }
    
    if (injuryImpact.severity !== 'Low') {
      reasons.push(injuryImpact.details[team1IsWinner ? 1 : 0]);
    }
    
    if (reasons.length < 2) {
      reasons.push(`${winningTeam.name} has better overall statistical performance`);
    }
    
    return reasons.slice(0, 3);
  }
}