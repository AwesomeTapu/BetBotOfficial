import axios from 'axios';
import { NBATeam, TeamStats, HeadToHeadStats, Player, GameResult } from '../types';

const BASE_URL = 'https://api.balldontlie.io/v1';

export class NBAApi {
  private static async get(endpoint: string) {
    try {
      const response = await axios.get(`${BASE_URL}${endpoint}`);
      return response.data;
    } catch (error) {
      console.error('NBA API Error:', error);
      throw error;
    }
  }

  static async getTeamStats(teamId: string): Promise<TeamStats> {
    const [teamStats, games] = await Promise.all([
      this.get(`/season_averages?team_ids[]=${teamId}`),
      this.get(`/games?team_ids[]=${teamId}&per_page=10&sort=-date`)
    ]);

    const stats = teamStats.data[0];
    const recentGames = games.data;

    // Calculate last 10 games stats
    const lastTenGamesStats = {
      ppg: recentGames.reduce((acc: number, game: any) => 
        acc + (game.home_team.id === teamId ? game.home_team_score : game.visitor_team_score), 0) / 10,
      oppPpg: recentGames.reduce((acc: number, game: any) => 
        acc + (game.home_team.id === teamId ? game.visitor_team_score : game.home_team_score), 0) / 10,
      avgMargin: recentGames.reduce((acc: number, game: any) => {
        const teamScore = game.home_team.id === teamId ? game.home_team_score : game.visitor_team_score;
        const oppScore = game.home_team.id === teamId ? game.visitor_team_score : game.home_team_score;
        return acc + (teamScore - oppScore);
      }, 0) / 10
    };

    return {
      ppg: stats.pts,
      fgPercentage: stats.fg_pct * 100,
      tpPercentage: stats.fg3_pct * 100,
      ftPercentage: stats.ft_pct * 100,
      reboundsPerGame: stats.reb,
      turnoversPerGame: stats.turnover,
      assistsPerGame: stats.ast,
      defensiveRating: 100 + (stats.opp_pts_per_game - stats.pts),
      offensiveRating: 100 + (stats.pts - stats.opp_pts_per_game),
      pace: stats.pace || 100,
      homeWinPercentage: stats.home_win_pct * 100,
      awayWinPercentage: stats.away_win_pct * 100,
      lastTenGamesStats
    };
  }

  static async getHeadToHeadStats(team1Id: string, team2Id: string): Promise<HeadToHeadStats> {
    const games = await this.get(
      `/games?team_ids[]=${team1Id}&team_ids[]=${team2Id}&per_page=10&sort=-date`
    );

    const lastGames: GameResult[] = games.data.map((game: any) => ({
      date: game.date,
      homeTeam: game.home_team.id,
      awayTeam: game.visitor_team.id,
      homeScore: game.home_team_score,
      awayScore: game.visitor_team_score,
      winner: game.home_team_score > game.visitor_team_score ? game.home_team.id : game.visitor_team.id,
      location: game.home_team.id === team1Id ? 'Home' : 'Away',
      attendance: 0, // Not provided by API
      keyStats: {
        leadingScorer: {
          name: 'N/A', // Would need additional API call for player stats
          points: 0,
          team: game.home_team.id
        },
        leadingRebounder: {
          name: 'N/A',
          rebounds: 0,
          team: game.home_team.id
        }
      }
    }));

    const team1Wins = lastGames.filter(game => 
      (game.homeTeam === team1Id && game.homeScore > game.awayScore) ||
      (game.awayTeam === team1Id && game.awayScore > game.homeScore)
    ).length;

    const team2Wins = lastGames.filter(game => 
      (game.homeTeam === team2Id && game.homeScore > game.awayScore) ||
      (game.awayTeam === team2Id && game.awayScore > game.homeScore)
    ).length;

    const pointDiffs = lastGames.map(game => {
      const team1Score = game.homeTeam === team1Id ? game.homeScore : game.awayScore;
      const team2Score = game.homeTeam === team2Id ? game.homeScore : game.awayScore;
      return team1Score - team2Score;
    });

    return {
      team1Wins,
      team2Wins,
      lastGames,
      averagePointDifferential: pointDiffs.reduce((a, b) => a + b, 0) / lastGames.length,
      averageTotalPoints: lastGames.reduce((acc, game) => acc + game.homeScore + game.awayScore, 0) / lastGames.length
    };
  }

  static async getTeamRoster(teamId: string): Promise<Player[]> {
    const players = await this.get(`/players?team_ids[]=${teamId}&per_page=20`);
    const playerStats = await this.get(`/season_averages?team_ids[]=${teamId}`);

    return players.data.map((player: any) => {
      const stats = playerStats.data.find((s: any) => s.player_id === player.id) || {};
      
      return {
        id: player.id.toString(),
        name: `${player.first_name} ${player.last_name}`,
        position: player.position || 'N/A',
        number: player.number || 'N/A',
        height: player.height_feet ? `${player.height_feet}'${player.height_inches}"` : 'N/A',
        weight: player.weight_pounds?.toString() || 'N/A',
        experience: (new Date().getFullYear() - new Date(player.birth_date).getFullYear()).toString(),
        college: player.college || 'N/A',
        stats: {
          gamesPlayed: stats.games_played || 0,
          gamesStarted: stats.games_started || 0,
          minutesPerGame: stats.min || 0,
          pointsPerGame: stats.pts || 0,
          reboundsPerGame: stats.reb || 0,
          assistsPerGame: stats.ast || 0,
          stealsPerGame: stats.stl || 0,
          blocksPerGame: stats.blk || 0,
          fieldGoalPercentage: (stats.fg_pct || 0) * 100,
          threePointPercentage: (stats.fg3_pct || 0) * 100,
          freeThrowPercentage: (stats.ft_pct || 0) * 100,
          turnoversPerGame: stats.turnover || 0,
          plusMinus: stats.plus_minus || 0
        },
        status: 'Active' // Would need additional API for injury status
      };
    });
  }
}