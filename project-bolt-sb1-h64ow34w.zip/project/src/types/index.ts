export interface NBATeam {
  id: string;
  name: string;
  abbreviation: string;
  primaryColor: string;
  secondaryColor: string;
  logoUrl: string;
  conference: 'Eastern' | 'Western';
  division: string;
  record: TeamRecord;
  roster: Player[];
}

export interface TeamRecord {
  wins: number;
  losses: number;
  winPercentage: number;
  lastTenGames: GameResult[];
  homeRecord: {
    wins: number;
    losses: number;
  };
  awayRecord: {
    wins: number;
    losses: number;
  };
  streak: {
    type: 'W' | 'L';
    count: number;
  };
}

export interface Player {
  id: string;
  name: string;
  position: string;
  number: string;
  height: string;
  weight: string;
  experience: string;
  college: string;
  stats: PlayerStats;
  status: 'Active' | 'Injured' | 'Out';
  injuryDetails?: string;
}

export interface PlayerStats {
  gamesPlayed: number;
  gamesStarted: number;
  minutesPerGame: number;
  pointsPerGame: number;
  reboundsPerGame: number;
  assistsPerGame: number;
  stealsPerGame: number;
  blocksPerGame: number;
  fieldGoalPercentage: number;
  threePointPercentage: number;
  freeThrowPercentage: number;
  turnoversPerGame: number;
  plusMinus: number;
}

export interface TeamStats {
  ppg: number;
  fgPercentage: number;
  tpPercentage: number;
  ftPercentage: number;
  reboundsPerGame: number;
  turnoversPerGame: number;
  assistsPerGame: number;
  defensiveRating: number;
  offensiveRating: number;
  pace: number;
  homeWinPercentage: number;
  awayWinPercentage: number;
  lastTenGamesStats: {
    ppg: number;
    oppPpg: number;
    avgMargin: number;
  };
  injuredPlayers?: Player[];
}

export interface HeadToHeadStats {
  team1Wins: number;
  team2Wins: number;
  lastGames: GameResult[];
  averagePointDifferential: number;
  averageTotalPoints: number;
}

export interface GameResult {
  date: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  winner: string;
  location: string;
  attendance: number;
  keyStats: {
    leadingScorer: {
      name: string;
      points: number;
      team: string;
    };
    leadingRebounder: {
      name: string;
      rebounds: number;
      team: string;
    };
  };
}

export interface Prediction {
  winner: NBATeam;
  winProbability: number;
  confidenceLevel: 'Low' | 'Medium' | 'High';
  keyReasons: string[];
  keyMatchups: {
    position: string;
    team1Player: Player;
    team2Player: Player;
    advantage: string;
    reason: string;
  }[];
  injuryImpact: {
    severity: 'Low' | 'Medium' | 'High';
    details: string[];
  };
  predictedScore: {
    team1: number;
    team2: number;
  };
}