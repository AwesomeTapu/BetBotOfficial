import React, { useState, useEffect } from 'react';
import { NBATeam } from '../types';
import { NBA_TEAMS } from '../data/nbaTeams';

interface TeamSelectorProps {
  onTeamSelect: (team: NBATeam) => void;
  selectedTeam: NBATeam | null;
  label: string;
  disabled?: boolean;
  otherSelectedTeam?: NBATeam | null;
}

const TeamSelector: React.FC<TeamSelectorProps> = ({
  onTeamSelect,
  selectedTeam,
  label,
  disabled = false,
  otherSelectedTeam
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [filteredTeams, setFilteredTeams] = useState<NBATeam[]>(NBA_TEAMS);

  // Filter out the other selected team from options
  useEffect(() => {
    let teams = NBA_TEAMS;
    if (otherSelectedTeam) {
      teams = teams.filter(team => team.id !== otherSelectedTeam.id);
    }
    
    if (searchTerm) {
      teams = teams.filter(team => 
        team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        team.abbreviation.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setFilteredTeams(teams);
  }, [searchTerm, otherSelectedTeam]);

  const handleInputClick = () => {
    if (!disabled) {
      setShowDropdown(true);
    }
  };

  const handleTeamSelect = (team: NBATeam) => {
    onTeamSelect(team);
    setSearchTerm('');
    setShowDropdown(false);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setShowDropdown(true);
  };

  return (
    <div className="relative w-full">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      
      <div 
        className={`relative rounded-lg border ${
          disabled ? 'bg-gray-100 border-gray-300' : 'border-blue-400 hover:border-blue-500'
        } focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-blue-600 transition-colors`}
      >
        {selectedTeam ? (
          <div 
            className="flex items-center p-2 cursor-pointer" 
            onClick={handleInputClick}
          >
            <div className="flex-shrink-0 w-8 h-8 mr-2">
              <img 
                src={selectedTeam.logoUrl}
                alt={selectedTeam.name}
                className="w-full h-full object-contain"
              />
            </div>
            <div>
              <p className="font-medium">{selectedTeam.name}</p>
            </div>
            {!disabled && (
              <button 
                className="ml-auto text-gray-400 hover:text-gray-600"
                onClick={(e) => {
                  e.stopPropagation();
                  onTeamSelect(null as unknown as NBATeam);
                }}
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="18" y1="6" x2="6" y2="18"></line>
                  <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
              </button>
            )}
          </div>
        ) : (
          <input
            type="text"
            value={searchTerm}
            onChange={handleSearchChange}
            onClick={handleInputClick}
            placeholder="Search team name or abbreviation"
            className={`w-full p-3 rounded-lg outline-none ${
              disabled ? 'bg-gray-100 text-gray-500' : 'bg-white'
            }`}
            disabled={disabled}
          />
        )}
      </div>
      
      {showDropdown && filteredTeams.length > 0 && !disabled && (
        <div className="absolute mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg z-10 max-h-60 overflow-y-auto">
          {filteredTeams.map(team => (
            <div
              key={team.id}
              className="flex items-center p-2 hover:bg-gray-100 cursor-pointer"
              onClick={() => handleTeamSelect(team)}
            >
              <div className="flex-shrink-0 w-6 h-6 mr-2">
                <img 
                  src={team.logoUrl}
                  alt={team.name}
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <p className="font-medium">{team.name}</p>
                <p className="text-xs text-gray-500">{team.abbreviation}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      
      {showDropdown && filteredTeams.length === 0 && !disabled && (
        <div className="absolute mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg z-10 p-2">
          <p className="text-gray-500">No teams found</p>
        </div>
      )}
    </div>
  );
};

export default TeamSelector;