import React from 'react';
import { NBATeam, HeadToHeadStats } from '../types';

interface HeadToHeadHistoryProps {
  team1: NBATeam;
  team2: NBATeam;
  headToHeadStats: HeadToHeadStats | null;
}

const HeadToHeadHistory: React.FC<HeadToHeadHistoryProps> = ({
  team1,
  team2,
  headToHeadStats
}) => {
  if (!headToHeadStats) {
    return null;
  }

  const totalGames = headToHeadStats.team1Wins + headToHeadStats.team2Wins;
  const team1WinPercentage = totalGames === 0 ? 0 : (headToHeadStats.team1Wins / totalGames) * 100;
  const team2WinPercentage = totalGames === 0 ? 0 : (headToHeadStats.team2Wins / totalGames) * 100;

  return (
    <div className="w-full bg-white rounded-lg shadow-md p-4">
      <h2 className="text-lg font-bold mb-4 text-center">Head-to-Head History</h2>
      
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <img 
            src={team1.logoUrl} 
            alt={team1.name} 
            className="w-8 h-8 mr-2"
          />
          <div>
            <p className="font-medium">{team1.name}</p>
            <p className="text-sm text-gray-600">{headToHeadStats.team1Wins} wins</p>
          </div>
        </div>
        <div className="flex items-center">
          <div className="text-right">
            <p className="font-medium">{team2.name}</p>
            <p className="text-sm text-gray-600">{headToHeadStats.team2Wins} wins</p>
          </div>
          <img 
            src={team2.logoUrl} 
            alt={team2.name} 
            className="w-8 h-8 ml-2"
          />
        </div>
      </div>
      
      {/* Win percentage bar */}
      <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden mb-6">
        <div className="flex h-full">
          <div 
            className="h-full transition-all duration-500 ease-out"
            style={{ 
              width: `${team1WinPercentage}%`,
              backgroundColor: team1.primaryColor
            }}
          ></div>
          <div 
            className="h-full transition-all duration-500 ease-out"
            style={{ 
              width: `${team2WinPercentage}%`,
              backgroundColor: team2.primaryColor
            }}
          ></div>
        </div>
      </div>
      
      <h3 className="font-medium mb-2">Recent Games</h3>
      
      <div className="space-y-3">
        {headToHeadStats.lastGames.map((game, index) => {
          const team1Win = game.winner === team1.id;
          
          return (
            <div key={index} className="border rounded-lg p-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center">
                  <img 
                    src={team1.logoUrl} 
                    alt={team1.name} 
                    className="w-6 h-6 mr-2"
                  />
                  <span className={`font-medium ${team1Win ? 'text-green-600' : ''}`}>
                    {game.team1Score}
                  </span>
                </div>
                
                <div className="text-xs text-gray-500">
                  {game.date}
                </div>
                
                <div className="flex items-center">
                  <span className={`font-medium ${!team1Win ? 'text-green-600' : ''}`}>
                    {game.team2Score}
                  </span>
                  <img 
                    src={team2.logoUrl} 
                    alt={team2.name} 
                    className="w-6 h-6 ml-2"
                  />
                </div>
              </div>
              <div className="flex justify-center mt-1">
                <div className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                  team1Win 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-blue-100 text-blue-700'
                }`}>
                  {team1Win ? `${team1.name} won` : `${team2.name} won`}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HeadToHeadHistory;