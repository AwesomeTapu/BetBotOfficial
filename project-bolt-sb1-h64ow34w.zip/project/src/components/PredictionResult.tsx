import React from 'react';
import { NBATeam, Prediction } from '../types';

interface PredictionResultProps {
  prediction: Prediction | null;
  team1: NBATeam;
  team2: NBATeam;
  isLoading: boolean;
}

const PredictionResult: React.FC<PredictionResultProps> = ({
  prediction,
  team1,
  team2,
  isLoading
}) => {
  if (isLoading) {
    return (
      <div className="w-full bg-white rounded-lg shadow-md p-6 text-center">
        <div className="flex justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700"></div>
        </div>
        <p className="mt-4 text-lg font-medium">Analyzing matchup data...</p>
        <p className="text-gray-500">Processing team statistics and matchup history</p>
      </div>
    );
  }

  if (!prediction) {
    return null;
  }

  const losingTeam = prediction.winner.id === team1.id ? team2 : team1;
  const winnerProbability = prediction.winProbability;
  const loserProbability = 100 - winnerProbability;

  // Determine confidence level color
  const confidenceColor = {
    Low: 'bg-yellow-500',
    Medium: 'bg-orange-500',
    High: 'bg-green-500'
  }[prediction.confidenceLevel];

  return (
    <div className="w-full bg-white rounded-lg shadow-md p-6 relative overflow-hidden">
      {/* Winner badge */}
      <div 
        className="absolute top-0 right-0 transform translate-x-8 -translate-y-8 rotate-45 w-48 py-1 text-center text-sm font-bold text-white"
        style={{ backgroundColor: prediction.winner.primaryColor }}
      >
        PREDICTED WINNER
      </div>
      
      <h2 className="text-xl font-bold mb-4 text-center">Prediction Result</h2>
      
      <div className="flex items-center justify-center gap-4 mb-6">
        <div className={`flex flex-col items-center p-4 rounded-lg ${
          prediction.winner.id === team1.id ? 'bg-green-50 ring-2 ring-green-500' : 'bg-gray-50'
        }`}>
          <img 
            src={team1.logoUrl} 
            alt={team1.name} 
            className="w-16 h-16 mb-2"
          />
          <p className="font-bold text-center">{team1.name}</p>
          <p className={`text-lg ${prediction.winner.id === team1.id ? 'text-green-600 font-bold' : 'text-gray-600'}`}>
            {prediction.winner.id === team1.id ? winnerProbability : loserProbability}%
          </p>
        </div>
        
        <div className="text-xl font-bold">VS</div>
        
        <div className={`flex flex-col items-center p-4 rounded-lg ${
          prediction.winner.id === team2.id ? 'bg-green-50 ring-2 ring-green-500' : 'bg-gray-50'
        }`}>
          <img 
            src={team2.logoUrl} 
            alt={team2.name} 
            className="w-16 h-16 mb-2"
          />
          <p className="font-bold text-center">{team2.name}</p>
          <p className={`text-lg ${prediction.winner.id === team2.id ? 'text-green-600 font-bold' : 'text-gray-600'}`}>
            {prediction.winner.id === team2.id ? winnerProbability : loserProbability}%
          </p>
        </div>
      </div>
      
      {/* Prediction bar */}
      <div className="w-full bg-gray-200 rounded-full h-4 mb-6 overflow-hidden">
        <div
          className="h-full rounded-full transition-all duration-1000 ease-out"
          style={{
            width: `${winnerProbability}%`,
            backgroundColor: prediction.winner.primaryColor
          }}
        ></div>
      </div>
      
      {/* Confidence level */}
      <div className="flex items-center mb-4">
        <p className="mr-2 font-medium">Confidence Level:</p>
        <span className={`${confidenceColor} text-white px-3 py-1 rounded-full text-sm font-medium`}>
          {prediction.confidenceLevel}
        </span>
      </div>
      
      {/* Key reasons */}
      <div className="mb-4">
        <h3 className="font-medium mb-2">Key Statistical Advantages:</h3>
        <ul className="list-disc ml-5 space-y-1">
          {prediction.keyReasons.map((reason, index) => (
            <li key={index} className="text-gray-700">{reason}</li>
          ))}
        </ul>
      </div>
      
      <div className="text-xs text-gray-500 italic text-center mt-4">
        *Prediction based on recent performance statistics and historical matchups
      </div>
    </div>
  );
};

export default PredictionResult;