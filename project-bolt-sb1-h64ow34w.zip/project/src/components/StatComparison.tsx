import React from 'react';
import { NBATeam, TeamStats } from '../types';

interface StatComparisonProps {
  team1: NBATeam;
  team2: NBATeam;
  team1Stats: TeamStats;
  team2Stats: TeamStats;
}

const StatComparison: React.FC<StatComparisonProps> = ({
  team1,
  team2,
  team1Stats,
  team2Stats
}) => {
  // Define the stats to display with labels and formatting
  const statsConfig = [
    { key: 'ppg', label: 'Points Per Game', format: '0.0', higherIsBetter: true },
    { key: 'fgPercentage', label: 'Field Goal %', format: '0.0%', higherIsBetter: true },
    { key: 'tpPercentage', label: 'Three Point %', format: '0.0%', higherIsBetter: true },
    { key: 'ftPercentage', label: 'Free Throw %', format: '0.0%', higherIsBetter: true },
    { key: 'reboundsPerGame', label: 'Rebounds', format: '0.0', higherIsBetter: true },
    { key: 'assistsPerGame', label: 'Assists', format: '0.0', higherIsBetter: true },
    { key: 'turnoversPerGame', label: 'Turnovers', format: '0.0', higherIsBetter: false },
    { key: 'offensiveRating', label: 'Offensive Rating', format: '0.0', higherIsBetter: true },
    { key: 'defensiveRating', label: 'Defensive Rating', format: '0.0', higherIsBetter: false },
    { key: 'pace', label: 'Pace', format: '0.0', higherIsBetter: true },
  ];

  const formatStat = (value: number, format: string): string => {
    if (format.includes('%')) {
      return `${value.toFixed(1)}%`;
    }
    return value.toFixed(1);
  };

  const getBarWidthPercentage = (team1Value: number, team2Value: number, higherIsBetter: boolean) => {
    const max = Math.max(team1Value, team2Value);
    const min = Math.min(team1Value, team2Value);
    
    // Get the percentage for each team (scaled to prevent bars from being too small)
    const range = max - min;
    const base = 30; // Minimum bar width percentage
    
    if (range === 0) {
      return { team1Width: 50, team2Width: 50 };
    }
    
    if (higherIsBetter) {
      return {
        team1Width: base + (team1Value - min) / range * (100 - base * 2),
        team2Width: base + (team2Value - min) / range * (100 - base * 2)
      };
    } else {
      return {
        team1Width: base + (max - team1Value) / range * (100 - base * 2),
        team2Width: base + (max - team2Value) / range * (100 - base * 2)
      };
    }
  };

  const getStatWinner = (stat: keyof TeamStats, higherIsBetter: boolean) => {
    const team1Value = team1Stats[stat];
    const team2Value = team2Stats[stat];
    
    if (team1Value === team2Value) return 'tie';
    
    if (higherIsBetter) {
      return team1Value > team2Value ? 'team1' : 'team2';
    } else {
      return team1Value < team2Value ? 'team1' : 'team2';
    }
  };

  return (
    <div className="w-full bg-white rounded-lg shadow-md p-4">
      <h2 className="text-lg font-bold mb-4 text-center">Statistical Comparison</h2>
      
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center">
          <img 
            src={team1.logoUrl} 
            alt={team1.name} 
            className="w-8 h-8 mr-2"
          />
          <span className="font-medium">{team1.name}</span>
        </div>
        <div className="flex items-center">
          <span className="font-medium">{team2.name}</span>
          <img 
            src={team2.logoUrl} 
            alt={team2.name} 
            className="w-8 h-8 ml-2"
          />
        </div>
      </div>
      
      <div className="space-y-4">
        {statsConfig.map(({ key, label, format, higherIsBetter }) => {
          const stat = key as keyof TeamStats;
          const team1Value = team1Stats[stat];
          const team2Value = team2Stats[stat];
          const { team1Width, team2Width } = getBarWidthPercentage(team1Value, team2Value, higherIsBetter);
          const winner = getStatWinner(stat, higherIsBetter);
          
          return (
            <div key={key} className="w-full">
              <div className="flex justify-between items-center mb-1">
                <span className={`text-sm font-medium ${winner === 'team1' ? 'text-green-600 font-bold' : ''}`}>
                  {formatStat(team1Value, format)}
                </span>
                <span className="text-xs text-gray-500">{label}</span>
                <span className={`text-sm font-medium ${winner === 'team2' ? 'text-green-600 font-bold' : ''}`}>
                  {formatStat(team2Value, format)}
                </span>
              </div>
              
              <div className="flex h-4 w-full">
                <div 
                  className={`h-full rounded-l transition-all duration-500 ease-out ${
                    winner === 'team1' ? `bg-${team1.primaryColor.replace('#', '')}` : 'bg-gray-300'
                  }`}
                  style={{ 
                    width: `${team1Width}%`,
                    backgroundColor: winner === 'team1' ? team1.primaryColor : undefined
                  }}
                ></div>
                <div 
                  className={`h-full rounded-r transition-all duration-500 ease-out ${
                    winner === 'team2' ? `bg-${team2.primaryColor.replace('#', '')}` : 'bg-gray-300'
                  }`}
                  style={{ 
                    width: `${team2Width}%`,
                    backgroundColor: winner === 'team2' ? team2.primaryColor : undefined
                  }}
                ></div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StatComparison;