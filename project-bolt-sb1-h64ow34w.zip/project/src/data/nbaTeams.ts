import { NBATeam } from '../types';

export const NBA_TEAMS: NBATeam[] = [
  {
    id: 'atl',
    name: 'Atlanta Hawks',
    abbreviation: 'ATL',
    primaryColor: '#E03A3E',
    secondaryColor: '#C1D32F',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612737/global/L/logo.svg'
  },
  {
    id: 'bos',
    name: 'Boston Celtics',
    abbreviation: 'BOS',
    primaryColor: '#007A33',
    secondaryColor: '#BA9653',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612738/global/L/logo.svg'
  },
  {
    id: 'bkn',
    name: 'Brooklyn Nets',
    abbreviation: 'BKN',
    primaryColor: '#000000',
    secondaryColor: '#FFFFFF',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612751/global/L/logo.svg'
  },
  {
    id: 'cha',
    name: 'Charlotte Hornets',
    abbreviation: 'CHA',
    primaryColor: '#1D1160',
    secondaryColor: '#00788C',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612766/global/L/logo.svg'
  },
  {
    id: 'chi',
    name: 'Chicago Bulls',
    abbreviation: 'CHI',
    primaryColor: '#CE1141',
    secondaryColor: '#000000',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612741/global/L/logo.svg'
  },
  {
    id: 'cle',
    name: 'Cleveland Cavaliers',
    abbreviation: 'CLE',
    primaryColor: '#860038',
    secondaryColor: '#041E42',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612739/global/L/logo.svg'
  },
  {
    id: 'dal',
    name: 'Dallas Mavericks',
    abbreviation: 'DAL',
    primaryColor: '#0053BC',
    secondaryColor: '#00285E',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612742/global/L/logo.svg'
  },
  {
    id: 'den',
    name: 'Denver Nuggets',
    abbreviation: 'DEN',
    primaryColor: '#0E2240',
    secondaryColor: '#FEC524',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612743/global/L/logo.svg'
  },
  {
    id: 'det',
    name: 'Detroit Pistons',
    abbreviation: 'DET',
    primaryColor: '#C8102E',
    secondaryColor: '#1D42BA',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612765/global/L/logo.svg'
  },
  {
    id: 'gsw',
    name: 'Golden State Warriors',
    abbreviation: 'GSW',
    primaryColor: '#1D428A',
    secondaryColor: '#FFC72C',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612744/global/L/logo.svg'
  },
  {
    id: 'hou',
    name: 'Houston Rockets',
    abbreviation: 'HOU',
    primaryColor: '#CE1141',
    secondaryColor: '#000000',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612745/global/L/logo.svg'
  },
  {
    id: 'ind',
    name: 'Indiana Pacers',
    abbreviation: 'IND',
    primaryColor: '#002D62',
    secondaryColor: '#FDBB30',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612754/global/L/logo.svg'
  },
  {
    id: 'lac',
    name: 'Los Angeles Clippers',
    abbreviation: 'LAC',
    primaryColor: '#C8102E',
    secondaryColor: '#1D428A',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612746/global/L/logo.svg'
  },
  {
    id: 'lal',
    name: 'Los Angeles Lakers',
    abbreviation: 'LAL',
    primaryColor: '#552583',
    secondaryColor: '#FDB927',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612747/global/L/logo.svg'
  },
  {
    id: 'mem',
    name: 'Memphis Grizzlies',
    abbreviation: 'MEM',
    primaryColor: '#5D76A9',
    secondaryColor: '#12173F',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612763/global/L/logo.svg'
  },
  {
    id: 'mia',
    name: 'Miami Heat',
    abbreviation: 'MIA',
    primaryColor: '#98002E',
    secondaryColor: '#F9A01B',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612748/global/L/logo.svg'
  },
  {
    id: 'mil',
    name: 'Milwaukee Bucks',
    abbreviation: 'MIL',
    primaryColor: '#00471B',
    secondaryColor: '#EEE1C6',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612749/global/L/logo.svg'
  },
  {
    id: 'min',
    name: 'Minnesota Timberwolves',
    abbreviation: 'MIN',
    primaryColor: '#0C2340',
    secondaryColor: '#236192',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612750/global/L/logo.svg'
  },
  {
    id: 'nop',
    name: 'New Orleans Pelicans',
    abbreviation: 'NOP',
    primaryColor: '#0C2340',
    secondaryColor: '#C8102E',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612740/global/L/logo.svg'
  },
  {
    id: 'nyk',
    name: 'New York Knicks',
    abbreviation: 'NYK',
    primaryColor: '#006BB6',
    secondaryColor: '#F58426',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612752/global/L/logo.svg'
  },
  {
    id: 'okc',
    name: 'Oklahoma City Thunder',
    abbreviation: 'OKC',
    primaryColor: '#007AC1',
    secondaryColor: '#EF3B24',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612760/global/L/logo.svg'
  },
  {
    id: 'orl',
    name: 'Orlando Magic',
    abbreviation: 'ORL',
    primaryColor: '#0077C0',
    secondaryColor: '#C4CED4',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612753/global/L/logo.svg'
  },
  {
    id: 'phi',
    name: 'Philadelphia 76ers',
    abbreviation: 'PHI',
    primaryColor: '#006BB6',
    secondaryColor: '#ED174C',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612755/global/L/logo.svg'
  },
  {
    id: 'phx',
    name: 'Phoenix Suns',
    abbreviation: 'PHX',
    primaryColor: '#1D1160',
    secondaryColor: '#E56020',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612756/global/L/logo.svg'
  },
  {
    id: 'por',
    name: 'Portland Trail Blazers',
    abbreviation: 'POR',
    primaryColor: '#E03A3E',
    secondaryColor: '#000000',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612757/global/L/logo.svg'
  },
  {
    id: 'sac',
    name: 'Sacramento Kings',
    abbreviation: 'SAC',
    primaryColor: '#5A2D81',
    secondaryColor: '#63727A',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612758/global/L/logo.svg'
  },
  {
    id: 'sas',
    name: 'San Antonio Spurs',
    abbreviation: 'SAS',
    primaryColor: '#C4CED4',
    secondaryColor: '#000000',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612759/global/L/logo.svg'
  },
  {
    id: 'tor',
    name: 'Toronto Raptors',
    abbreviation: 'TOR',
    primaryColor: '#CE1141',
    secondaryColor: '#000000',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612761/global/L/logo.svg'
  },
  {
    id: 'uta',
    name: 'Utah Jazz',
    abbreviation: 'UTA',
    primaryColor: '#002B5C',
    secondaryColor: '#00471B',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612762/global/L/logo.svg'
  },
  {
    id: 'was',
    name: 'Washington Wizards',
    abbreviation: 'WAS',
    primaryColor: '#002B5C',
    secondaryColor: '#E31837',
    logoUrl: 'https://cdn.nba.com/logos/nba/1610612764/global/L/logo.svg'
  }
];

export const getTeamByName = (name: string): NBATeam | undefined => {
  return NBA_TEAMS.find(team => 
    team.name.toLowerCase() === name.toLowerCase() || 
    team.abbreviation.toLowerCase() === name.toLowerCase()
  );
};

export const getTeamById = (id: string): NBATeam | undefined => {
  return NBA_TEAMS.find(team => team.id === id);
};