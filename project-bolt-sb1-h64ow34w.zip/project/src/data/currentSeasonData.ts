import { format, subDays } from 'date-fns';
import { NBATeam, Player, GameResult } from '../types';

// This would normally come from an API, but we'll simulate current season data
export const generateCurrentSeasonData = (team: NBATeam): {
  record: NBATeam['record'];
  roster: Player[];
  recentGames: GameResult[];
} => {
  // Seed random based on team ID for consistency
  const seed = team.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const random = (min: number, max: number): number => {
    const x = Math.sin(seed) * 10000;
    return min + (((x - Math.floor(x)) + Math.random()) / 2) * (max - min);
  };

  // Generate realistic win-loss record
  const totalGames = 82;
  const gamesPlayed = 65; // Roughly March of the season
  const wins = Math.floor(random(20, 45));
  const losses = gamesPlayed - wins;

  // Generate last 10 games
  const lastTenGames: GameResult[] = Array.from({ length: 10 }, (_, i) => {
    const isHome = random(0, 1) > 0.5;
    const score = Math.floor(random(100, 120));
    const oppScore = Math.floor(random(95, 115));
    const date = format(subDays(new Date(), i + 1), 'yyyy-MM-dd');

    return {
      date,
      homeTeam: isHome ? team.id : 'OPP',
      awayTeam: isHome ? 'OPP' : team.id,
      homeScore: isHome ? score : oppScore,
      awayScore: isHome ? oppScore : score,
      winner: score > oppScore ? team.id : 'OPP',
      location: isHome ? 'Home' : 'Away',
      attendance: Math.floor(random(15000, 20000)),
      keyStats: {
        leadingScorer: {
          name: 'Player Name',
          points: Math.floor(random(20, 35)),
          team: team.id
        },
        leadingRebounder: {
          name: 'Player Name',
          rebounds: Math.floor(random(8, 15)),
          team: team.id
        }
      }
    };
  });

  // Generate roster with current season stats
  const roster: Player[] = [
    {
      id: `${team.id}-1`,
      name: 'Star Player',
      position: 'PG',
      number: '1',
      height: "6'3\"",
      weight: '185',
      experience: '8',
      college: 'Kentucky',
      stats: {
        gamesPlayed: gamesPlayed,
        gamesStarted: gamesPlayed,
        minutesPerGame: random(32, 38),
        pointsPerGame: random(20, 28),
        reboundsPerGame: random(3, 6),
        assistsPerGame: random(6, 9),
        stealsPerGame: random(1, 2),
        blocksPerGame: random(0.2, 0.8),
        fieldGoalPercentage: random(44, 52),
        threePointPercentage: random(35, 42),
        freeThrowPercentage: random(82, 92),
        turnoversPerGame: random(2, 4),
        plusMinus: random(2, 8)
      },
      status: 'Active'
    },
    // Add more players...
  ];

  return {
    record: {
      wins,
      losses,
      winPercentage: wins / gamesPlayed,
      lastTenGames,
      homeRecord: {
        wins: Math.floor(wins * 0.6),
        losses: Math.floor(losses * 0.4)
      },
      awayRecord: {
        wins: Math.floor(wins * 0.4),
        losses: Math.floor(losses * 0.6)
      },
      streak: {
        type: random(0, 1) > 0.5 ? 'W' : 'L',
        count: Math.floor(random(1, 5))
      }
    },
    roster,
    recentGames: lastTenGames
  };
};