import { NBAApi } from '../services/nbaApi';
import { NBATeam, TeamStats, HeadToHeadStats } from '../types';

export const getTeamStats = async (team: NBATeam): Promise<TeamStats> => {
  try {
    return await NBAApi.getTeamStats(team.id);
  } catch (error) {
    console.error('Error fetching team stats:', error);
    throw error;
  }
};

export const getHeadToHeadStats = async (team1: NBATeam, team2: NBATeam): Promise<HeadToHeadStats> => {
  try {
    return await NBAApi.getHeadToHeadStats(team1.id, team2.id);
  } catch (error) {
    console.error('Error fetching head-to-head stats:', error);
    throw error;
  }
};